## Variable

- LocalVariable
- GlobalVariable
- EnumVariable
- ModuleVariable
